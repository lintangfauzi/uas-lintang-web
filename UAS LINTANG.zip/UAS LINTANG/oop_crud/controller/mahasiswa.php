<?php
    include '../Database.php';
    include '../model/mahasiswa_model.php';
class mahasiswa {
    public $model;
    function __construct(){
        $db = new database();
        $con = $db->DBconnect();
        $this->model = new mahasiswa_model($con);
    }
    
    function index(){
        session_start();
        if(!empty($_SESSION)){
            $mahasiswa = $this->model->tampil_data();
            return $mahasiswa;
    }else{
        header("Location:login.php");
    }
}

    function getData($id){
        $hasil = $this->model->getData($id);
        return $hasil;
    }

    function getdatamahasisiwa(){
         $hasil = $this->model->getdatamahasisiwa();
         return $hasil;
    }

    function hapusSurat(){
        if(isset($_POST['delete'])){
            $id = $_POST['id'];

            $result = $this ->model->hapusData($id);

            if($result){
                header("Location:content.php?pesan=succes&frm=del");
            }else{
                header("Location:content.php?pesan=gagal&frm=del");
            }
        }
    }

    function simpanData(){
        if(isset($_POST['simpan'])) {
            $nim = $_POST['nim'];
            $nama= $_POST['nama'];
            $alamat = $_POST['alamat'];
            $nomerhp = $_POST['nomerhp'];
            $extrakulikuler = $_POST['extrakulikuler'];

            $data[] = array(
                    'nim' => $nim,
                    'nama'=> $nama, 
                    'alamat' => $alamat, 
                    'nomerhp' => $nomerhp,
                    'extrakulikuler' => $extrakulikuler,
            );

            $result = $this->model->simpanData($data);

            if($result){
                header("Location:index.php?pesan=success&frm=add");
            }else{
                header("Location:index.php?pesan=gagal&frm=add");
            }
        }
    }

    function Updatemahasiswa(){
        if(isset($_POST['simpan'])) {
            $nim = $_POST['nim'];
            $nama= $_POST['nama'];
            $alamat = $_POST['alamat'];
            $nomerhp = $_POST['nomerhp'];
            $extrakulikuler = $_POST['extrakulikuler'];

            $data = array(
                'nim' => $nim,
                'nama'=> $nama, 
                'alamat' => $alamat, 
                'nomerhp' => $nomerhp,
                'extrakulikuler' => $extrakulikuler,
            );

            $result = $this->model->UpdateData($data,$nim);

            if($result){
                header("Location:index.php?pesan=success&frm=edit");
            }else{
                header("Location:index.php?pesan=gagal&frm=edit");
            }
        }
    }
}
?>