<?php
include '../controller/auth.php';
$ctrl = new auth();
session_start();

$code = $ctrl->acakCaptcha();
$_SESSION["code"] = $code;

//lebar dan tinggi captcha
$wh = imagecreatetruecolor(164,30);

//background color biru
$bgc = imagecolorallocate($wh, 21, 66, 120);

//text color abu-abu
$fc = imagecolorallocate($wh, 223, 230, 233,);
imagefill($wh, 4, 4, $bgc);

//( $image , $fontsize , $string , $fontcolor)
imagestring($wh, 10, 50, 15, $code, $fc);

//buat gambar
header('content-type: image/jpg');
imagejpeg($wh);
imagedestroy($wh);
?>