<?php
$con = new mysqli("localhost", "root", "", "oop_lintang");

$tgl = date('d F Y');

$query = mysqli_query($con, 'SELECT * FROM tbl_extra');

?>
<!DOCTYPE html>
<html>
<head>
    <title>TambahData Mahasiswa</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
    <row>
            <div class="card">
            <h1 style="text-align:center"><b>TAMBAH DATA MAHASISWA</b></h1>
            <div class="card-body">
            <form class="row g-3" method="post" action="add.php" name="tambahh">
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">nim</label>
    <input type="text" class="form-control" id="nim" name="nim" placeholder="001">
  </div>
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">nama</label>
    <input type="text" class="form-control" id="nama" name="nama" placeholder="budi">
  </div>
  <div class="col-md-6">
    <label for="inputState" class="form-label">extrakulikuler</label>
    <select id="extrakulikuler" name="extrakulikuler" class="form-select">
      <option selected>Pilihan</option>
      <?php
      foreach ($query as $js) {
      ?>
      <option value="<?=$js['id']?>"><?=$js['extrakulikuler']?></option>
      <?php
      }
      ?>
    </select>
  </div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">alamat</label>
    <input type="text" class="form-control" id="alamat" name="alamat">
  </div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">nomer hp</label>
    <input type="text" class="form-control" id="nomerhp" name="nomerhp">
  </div>
  <div class="col-12">
    <button type="simpan"id="simpan" name="simpan"class="btn btn-primary">Add</button>
    <button type="reset" class="btn btn-danger">Cancel</button>
  </div>
</form>
    </div>        
</div>
</row>
</div>
    <?php

    if(isset($_POST['simpan'])) {
        $nim = $_POST['nim'];
        $nama= $_POST['nama'];
        $alamat = $_POST['alamat'];
        $nomerhp = $_POST['nomerhp'];
        $extrakulikuler = $_POST['extrakulikuler'];

        $result = mysqli_query($con, "INSERT INTO `tbl_mahasiswa` (`id`, `nim`, `nama`, `alamat`, `nomerhp`, `extrakulikuler`) VALUES (NULL, '$nim', '$nama', '$alamat ', '$nomerhp', '$extrakulikuler');");
        
        header("Location:content.php?pesan=success&frm=add");
    }
    ?>
    
</body>
<script src="..assets/js/bootstrap.bundle.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</html>
