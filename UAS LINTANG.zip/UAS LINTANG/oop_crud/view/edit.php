<?php
include '../controller/mahasiswa.php';

$ctrl = new mahasiswa();
$id = $_GET['id'];
$dataisi = $ctrl->getData($id);
$js = datamahasisiwa();

if($isi["extrakulikuler"]=='1'){
    $jb = "vollyball";
} else if($isi["extrakulikuler"]=='2'){
    $jb = "badminton";
} else if($isi["extrakulikuler"]=='3'){
    $jb = "futsal";
} else if($isi["extrakulikuler"]=='4'){
    $jb = "catur";
} else{
    $jb = "Kode Bermasalah";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>edit Data mahasiswa</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
    <row>
            <div class="card">
            <h1 style="text-align:center"><b>EDIT DATA MAHASISWA</b></h1>
            <div class="card-body">
            <form class="row g-3" method="post" action="<?php echo $ctrl->Updatemahasiswa($id);?>" name="tambahh">
            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $isi['id'];?>">
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">NIM</label>
    <input type="text" class="form-control" id="nim" name="nim" value="<?php echo $isi['nim'] ?>" placeholder="">
  </div>
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">NAMA</label>
    <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $isi['nama'] ?>" placeholder="">
    </div>
  <div class="col-md-6">
    <label for="inputState" class="form-label">extrakulikuler</label>
    <select id="extrakulikuler" name="extrakulikuler" class="form-select">
      <option selected value="<?php echo $isi['extrakulikuler']?>"><?php echo $js ?> </option>
      <option value=1>vollyball</option>
      <option value=2>badminron</option>
      <option value=3>futsal</option>
      <option value=4>catur</option>
    </select>
  </div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">ALAMAT</label>
    <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo $isi['alamat'] ?>">
  </div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">NOMERHP</label>
    <input type="text" class="form-control" id="nomerhp" name="nomerhp" value="<?php echo $isi['nomerhp'] ?>">
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary" name="update" id=>Update</button>
    <button type="submit" class="btn btn-danger">Cancel</button>
  </div>
</form>
    </div>        
</div>
</row>
</div>
    <?php

    if(isset($_POST['update'])) {
        $id = $_POST['id'];
        $nim = $_POST['nim'];
        $nama= $_POST['nama'];
        $alamat = $_POST['alamat'];
        $nomerhp = $_POST['nomerhp'];
        $extrakulikuler = $_POST['extrakulikuler'];

        $result = mysqli_query($con, "UPDATE `tbl_mahasiswa` SET `nim` = '$nim', `nama` = '$nama', `alamat` = '$alamat', `nomerhp` = '$nomerhp', `extrakulikuler` 
        = ' $extrakulikuler' WHERE `tbl_mahasiswa`.`$id`");
        
        header("Location:view.php?pesan=success&frm=edit");
    }
    ?>
    
</body>
<script src="..assets/js/bootstrap.bundle.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</html>