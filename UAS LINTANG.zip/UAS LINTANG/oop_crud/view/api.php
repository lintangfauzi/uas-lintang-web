<?php
     header("Access-Control-allow-Origin:*");
     header("Content-Type:application/json;charset=UTF-8");
     header("Access-Control-allow-Methods:POST,GET,PUT,DELETE");
     header("Access-Control-Max-Age:3600");
     header("Access-Control-Allow-Headers:content-Type,access-control-Allow-Headers,Authorization,X-Requested-With");
     //get database connection
     include '../controller/mahasiswa.php';
     $ctrl = new mahasiswa();
     $request = $_SERVER['REQUEST_METHOD'];
     switch($request)
    {
        case 'GET' :
        $ctrl->getdatamahasisiwa();

        break;
        case ' POST' :
        $ctrl->simpanjenis();    
        break;

        case 'PUT' :
        break;
        case 'DELETE' :
        break;
        default :
        http_response_code(404);
        echo "Request tidak diizinkan";
    }
?>        

