<?php
include '../controller/mahasiswa.php';

//var_dump($hasil);

$ctrl = new mahasiswa();

$hasil = $ctrl->index();

?>
<!DOCTYPE html>
<html>
<head>
    <title>View Data mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
    <h1 style="text-align:center"><b>Data mahasiswa</b></h1>
    <a class="btn btn-primary" href="add.php" role="button">Tambah</a>
    <a class="btn btn-primary" href="login.php" role="button">Logout</a>

    <table class="table mt-2">
    
        <thead class="table-dark">
            <td><b>Nim</b></td>
            <td><b>Nama</b></td>
            <td><b>Alamat</b></td>
            <td><b>Nomerhp</b></td>
            <td><b>Extrakulikuler</b></td>
            <td colspan="2"><b>ACTION</b></td>
        </thead>
    <tbody class="table-primary">
    <?php
	foreach ($hasil as $isi) {
		if($isi["extrakulikuler"]=='1'){
			$js = "vollyball";
		} else if($isi["extrakulikuler"]=='2'){
			$js = "badminton";
		} else if($isi["extrakulikuler"]=='3'){
			$js = "futsal";
        } else if($isi["extrakulikuler"]=='4'){
			$js = "catur";
		} else{
			$js = "Kode Bermasalah";
		}
		?>

	<tr>
		<td><?php echo $isi['nim'];?></td>
		<td><?php echo $isi['nama'];?></td>
		<td><?php echo $isi['alamat'];?></td>
        <td><?php echo $isi['nomerhp'];?></td>
        <td><?php echo $js;?></td>
        <td><a href="edit.php?id=<?php echo $isi['id'];?>">EDIT</a></td>
        <td><a href="#" data-bs-toggle="modal" data-bs-target="#deletesurat<?php echo $isi['id'];?>">HAPUS</a></td>
	</tr>

    <div class="example-modal">
        <div id="deletesurat<?php echo $isi['id'];?>" class="modal fade" role="dialog" style="display:none;">
            <div class="modal-dialog">
                <div class="modal-content">
                <form class="row g-3" method="post" action="<?php $ctrl->hapusSurat()?>" name="tambahh" name="form1">
                    <div class="modal-header">
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title">Konfirmasi Delete data Mahasiswa</h3>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="id" name="id" value="<?php echo $isi['id'];?>">
                        <h4 class="text-center">Apakah Anda Yakin Ingin Menghapus nim <?php echo $isi['nim'];?><strong><span class="grt"></span></strong></h4>
                    </div>
                    <div class="modal-footer">
                        <button id="nodelete" type="button" class="btn btn-danger pull-left" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" name="delete" id="delete">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php

    }
    ?>
    </tbody>
    </table>
    <?php

     if(isset($_POST['update'])) {
         $id = $_POST['id'];

         $result = mysqli_query($con, "DELETE FROM `tbl_mahasiswa` WHERE `tbl_mahasiswa`.`id` = $id");
        
      }
    ?>
    </div>
</body>
<script src="..assets/js/bootstrap.bundle.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</html>